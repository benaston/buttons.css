var app = app || {};

app.ItemListModel = function (name) {
    "use strict";

    if (!(this instanceof app.ItemListModel)) {
        return new app.ItemListModel();
    }

    var self = this;
    self.items = new Array();
    self.name = name;
    this.updateNotificationUri = "update://app.ItemListModel";   

    this.addItem = function (id) {
        self.items.push(id);
        $.publish(self.updateNotificationUri);
    };

    this.removeItem = function (id) {        
        self.items.splice(self.items.indexOf(id), 1);
        $.publish(self.updateNotificationUri);
    };    

    function init() {
        return self;
    }

    return init();
};
