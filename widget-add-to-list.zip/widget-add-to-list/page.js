jQuery(document).ready(function () {    
    app.app = new app.ItemListView(new app.ItemListModel("favourites"));
}); 
